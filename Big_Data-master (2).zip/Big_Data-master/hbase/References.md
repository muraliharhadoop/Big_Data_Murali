* https://github.com/GoogleCloudPlatform/cloud-bigtable-examples/tree/master/java/simple-cli
* https://autofei.wordpress.com/2012/04/02/java-example-code-using-hbase-data-model-operations/
* http://lirenjuan.iteye.com/blog/1470645
* https://community.hortonworks.com/articles/2038/how-to-connect-to-hbase-11-using-java-apis.html