package me.tingri.graphs.cc;

import me.tingri.graphs.gimv.GIMVIdentityMapper;

/**
 * Created by sandeep on 12/23/15.
 */
public class StateCheckMapper extends GIMVIdentityMapper {
}
