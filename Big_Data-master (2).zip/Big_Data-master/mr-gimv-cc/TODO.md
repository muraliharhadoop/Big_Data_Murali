
* args4j for parsing commandline arguments
    * ToolRunner and args4j both solve similar problems -- ToolRunner is limited
//TODO for debugging retain all intermediate vectors
