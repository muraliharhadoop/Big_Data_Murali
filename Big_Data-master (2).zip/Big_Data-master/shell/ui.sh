#!/bin/bash
# Browse HDFS and check health using http://localhost:50070 in the browser:
xdg-open http://localhost:50070
# You can check the status of the applications running using the following URL:
xdg-open http://localhost:8088
