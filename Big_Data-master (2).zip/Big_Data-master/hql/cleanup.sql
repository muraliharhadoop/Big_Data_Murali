drop table if exists page_view;
drop table if exists apachelog;
drop table if exists apachelog_text;
drop table if exists apachelog_orc;
drop table if exists strange_string;
drop table if exists india_pow_gen;
drop table if exists nodes;
drop table if exists nodes_string;
drop table if exists edges;
drop table if exists edges_string;
drop table if exists components;

DROP FUNCTION IF EXISTS rowWithHeader;
DROP FUNCTION IF EXISTS components;
DROP FUNCTION IF EXISTS components_wqupc;
