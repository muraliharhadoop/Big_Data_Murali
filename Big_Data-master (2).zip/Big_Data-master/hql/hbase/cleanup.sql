drop table if exists nodes;
drop table if exists nodes_string;
drop table if exists edges;
drop table if exists edges_string;
drop table if exists hbase_edges;